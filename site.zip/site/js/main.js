const videoPlayer = document.getElementById("videoPlayer");
const playPauseBtn = document.getElementById("playPauseBtn");
const volumeSlider = document.getElementById("volumeSlider");
const progressSlider = document.getElementById("progressSlider");
const fullscreenBtn = document.getElementById("fullscreenBtn");
const timeDisplay = document.getElementById("timeDisplay");
const customBtn = document.getElementById("customBtn");
const video = document.querySelector('video');

video.addEventListener('fullscreenchange', () => {
  if (document.fullscreenElement) {
    // В полноэкранном режиме
    video.controls = false; // Скрыть стандартные элементы управления
    document.body.classList.add('fullscreen-video'); // Добавить класс для стилей в полноэкранном режиме
  } else {
    // Выход из полноэкранного режима
    video.controls = true; // Показать стандартные элементы управления
    document.body.classList.remove('fullscreen-video'); // Удалить класс для стилей в полноэкранном режиме
  }
});


playPauseBtn.addEventListener("click", () => {
  if (videoPlayer.paused || videoPlayer.ended) {
    videoPlayer.play();
    playPauseBtn.textContent = "Pause";
  } else {
    videoPlayer.pause();
    playPauseBtn.textContent = "Play";
  }
});

volumeSlider.addEventListener("input", () => {
  videoPlayer.volume = volumeSlider.value;
});

progressSlider.addEventListener("input", () => {
  videoPlayer.currentTime = videoPlayer.duration * (progressSlider.value / 100);
});

fullscreenBtn.addEventListener("click", () => {
  if (videoPlayer.requestFullscreen) {
    videoPlayer.requestFullscreen();
  } else if (videoPlayer.webkitRequestFullscreen) { /* Safari */
    videoPlayer.webkitRequestFullscreen();
  } else if (videoPlayer.msRequestFullscreen) { /* IE11 */
    videoPlayer.msRequestFullscreen();
  }
});

customBtn.addEventListener("click", () => {
  // Добавьте свой код для обработки клика по кнопке "Custom"
});

videoPlayer.addEventListener("timeupdate", () => {
  const currentTime = videoPlayer.currentTime;
  const duration = videoPlayer.duration;
  progressSlider.value = (currentTime / duration) * 100;
  timeDisplay.textContent = formatTime(currentTime) + " / " + formatTime(duration);
});

function formatTime(time) {
  const minutes = Math.floor(time /  60);
  const seconds = Math.floor(time % 60);
  return leadingZero(minutes) + ":" + leadingZero(seconds);
}

function leadingZero(number) {
  return number < 10 ? "0" + number : number;
}

